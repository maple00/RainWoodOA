package com.rainwood.oa.ui.activity;

/**
 * create by a797s in 2020/5/14 9:17
 * 
 * @Description : 补卡记录
 * @Usage : 用于展示个人的补卡记录和行政事务中的补卡记录
 **/
public final class CardRecords {

}
