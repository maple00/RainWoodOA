package com.rainwood.oa.model;

/**
 * @Author: a797s
 * @Date: 2020/4/28 16:16
 * @Desc: 网络请求接口
 */
public interface Api {
}
