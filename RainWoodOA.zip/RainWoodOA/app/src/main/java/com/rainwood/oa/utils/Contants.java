package com.rainwood.oa.utils;

/**
 * @Author: a797s
 * @Date: 2020/4/27 15:50
 * @Desc: 常量
 */
public final class Contants {

    /**
     * 网络请求失败
     */
    public static final String HTTP_MSG_RESPONSE_FAILED = "The request data failed and the response code is not 200,code = ";


}
